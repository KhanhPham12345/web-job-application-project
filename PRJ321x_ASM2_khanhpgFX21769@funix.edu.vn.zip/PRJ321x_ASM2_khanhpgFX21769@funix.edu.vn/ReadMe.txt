Hướng dẫn sử dụng 
Chạy code sql từng block để tạo cơ sở dữ liệu và các bảng.
Chạy application như bình thường.
Lưu ý:
Muốn upload ảnh (logo công ty/ ảnh cá nhân) lên application thì đưa ảnh vào google drive, chọn share link cho phép view. 
Copy và paste link google drive đó vào những trường thông tin có yêu câu up ảnh(logo công ty/ ảnh cá nhân). 

